# Gradia portable kit

Copy gradia/ for the prebuilt ESM + types, or gradient/ for editable sources. React is only needed for the React adapter. Read docs/integration.md and docs/agents.md.

Studio: https://gradia.plinka.eu
Source: https://github.com/ExtraBinoss/Gradia
