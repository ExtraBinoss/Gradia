/** Dependency-free public ESM entry. Importing it is SSR-safe; construct in the browser. */
export * from "../core";
export * from "./index";
